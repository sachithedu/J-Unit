package com.comp301.a04junit.adept;

public interface Item {

  String getName();

  boolean equals(Item other);
}
