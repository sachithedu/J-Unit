package com.comp301.a04junit.adept;

/**
 * You do not have to make changes to this file for a04-junit. This file represents a class that you
 *   should write tests for. You are not required to implement this class yourself. See the readme
 *   for instructions on what this class is supposed to do.
 */
public class ItemImpl implements Item {

  public ItemImpl(String name) {

  }

  @Override
  public String getName() {
    return null;
  }

  @Override
  public boolean equals(Item other) {
    return false;
  }
}
