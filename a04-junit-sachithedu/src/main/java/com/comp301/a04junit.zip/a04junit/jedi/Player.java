package com.comp301.a04junit.jedi;

import com.comp301.a04junit.adept.Item;

/**
 * You do not have to make changes to this file for a04-junit. This file represents a class that you
 *   should write tests for. You are not required to implement this class yourself. See the readme
 *   for instructions on what this class is supposed to do.
 */
public class Player {

  public Player(String name) {

  }

  public String getName() {
    return null;
  }

  public String toString() {
    return null;
  }

  public void addItem(Item item) {

  }

  public Item getItem(int index) {
    return null;
  }

  public void removeItem(Item item) {

  }

  public Item removeItem(int index) {
    return null;
  }

  public boolean hasItem(Item item) {
    return false;
  }

  public int getCapacity() {
    return 0;
  }

  public int getNumItems() {
    return 0;
  }

  public void moveNorth() {

  }

  public void moveSouth() {

  }

  public void moveWest() {

  }

  public void moveEast() {

  }

  public int getLocX() {
    return 0;
  }

  public int getLocY() {
    return 0;
  }
}
